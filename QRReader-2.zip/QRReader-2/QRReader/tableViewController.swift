//
//  tableViewController.swift
//  QRReader
//
//  Created by Gorkem İskenderoglu on 15.11.2017.
//  Copyright © 2017 MAGNUMIUM. All rights reserved.
//

import UIKit

class tableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var Mould = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self
        
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = "kalıp"
        return cell
    }
    
    @IBAction func addButtonClicked(_ sender: Any) {
         performSegue(withIdentifier: "toYeniKalipOkut", sender: nil)
    }
    
    
    
    
}
