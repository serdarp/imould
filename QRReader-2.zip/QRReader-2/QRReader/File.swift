//
//  File.swift
//  QRReader
//
//  Created by Gorkem İskenderoglu on 13.11.2017.
//  Copyright © 2017 MAGNUMIUM. All rights reserved.
//

import Foundation
import AVFoundation
import Parse

class AnaEkran: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
}
